public interface ParkingSpotState {
    void handleRequest(ParkingSpot spot);
}
