package main;

import views.LoginFrame;

public class Main {
    public static void main(String[] args) {
        // Login ekranını başlat
        new LoginFrame();
    }
}
